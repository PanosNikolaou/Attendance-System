<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Highcharts Example</title>
		
		
		<!-- 1. Add these JavaScript inclusions in the head of your page -->
		<script type="text/javascript" src="jquery-1.js"></script>
		<script type="text/javascript" src="highcharts.js"></script>
		

		<?php
		
		$conn = new mysqli("localhost", "root", "", "attendance");
				
		$result = $conn->query("SELECT whours FROM user_time WHERE id_user=2 ORDER BY date DESC LIMIT 1");

		
		while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
			$data = $rs['whours'];
			echo $data;
		}
		
		?>

		<script>

		var chart = new Highcharts.Chart({
		chart: {
        renderTo: 'container'
		},
		series: [{
        data: [<?php echo join($data, ',') ?>],
        pointStart: 0,
        pointInterval
		}]
		});
		
		</script>
		
	</head>
	<body>
		<!-- 3. Add the container -->
		<div id="container" style="width: 800px; height: 400px; margin: 0 auto"/>
	</body>
	</html>
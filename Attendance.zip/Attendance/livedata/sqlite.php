<?php
//copy("C:/edss/test.db","C:/edss/test2.db");
class MyDB extends SQLite3
{
	function __construct()
	{
		$this->open('C:/edss/serm.db');
	}
}

$db = new MyDB();
if(!$db){
	echo $db->lastErrorMsg();
}else{
	echo "DB Opened successfully!";
}

$sql =<<<EOF
		INSERT INTO data_means (DATETIME,SMOKE,TEMPERATURE,HUMIDITY,WINDSPEED,WINDDIR,RISK)
		VALUES ('2017-02-02 16:08:08',56,40,78,10,'S',123);
EOF;

	$ret = $db->query($sql);
	if(!$ret){
		echo $db->lastErrorMsg();
	}else{
		echo "Record created successfully";
	}

$sql = <<<EOF
		SELECT * FROM data_means;
EOF;

$ret = $db->query($sql);


while($row = $ret->fetchArray(SQLITE3_ASSOC)){
	echo "RECID:" . $row['recid'] . "\n";
	echo "DATETIME:" . $row['datetime'] . "\n";
	echo "RISK:" . $row['risk'] . "\n\n";
}

//$result	= sqlite_query($dbhandle, $query);
//if(!result) die ("Cannot execute query!");

//$row = sqlite_fetch_array($result, SQLITE_ASSOC);
//print_r($row)
?>
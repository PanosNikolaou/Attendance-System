<!doctype html>

<html lang="en">
<head>
    <title>my first komodo jquery page</title>
    <style type="text/css">
        .BlueDiv {background-color:Navy;color:White;}
        .RedDiv {background-color:Red;color:White;}
    </style>
    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript">
        window.onload = function(){
            alert('window loaded');
        };
        
        $(document).ready(function(){
            alert('document ready!');
            $('#myContent').html('Changed Content!');
            $('table').html('####');
            var coll = $('myContent');
            alert(coll.lenght);
            //$('table').lenght();
            $('div').each(function(){
                alert($(this).html());
            });
            $('#secdiv').css("background","green");
        });
    </script>
</head>
<body>
<h1>hello</h1>
    <div id="myContent">
        My jQuery enabled page!
    </div>
    <div id="secdiv">
        My Sec Div
    </div>
    <table>
        <tr>
            <td> one </td>
            <td> second </td>
        </tr>
        <tr>
            <td> one </td>
            <td> second </td>
        </tr>
    </table>
</body>
</html>
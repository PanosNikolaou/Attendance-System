<?php
class MyDB extends SQLite3
{
	function __construct()
	{
		$this->open('C:/edss/serm_shadow.db');
	}
}

$db = new MyDB();
/* if(!$db){
	echo $db->lastErrorMsg();
}else{
	echo "DB Opened successfully!";
} */

// Set the JSON header
header("Content-type: text/json");

// The x value is the current JavaScript time, which is the Unix time multiplied 
// by 1000.

$x = time() * 1000;

$sql = <<<EOF
		SELECT * FROM data;
EOF;

		$result = $db->query($sql);
		
		while($rs = $result->fetchArray(SQLITE3_ASSOC)) {
			$wndspd = floatval($rs['windspeed']);
			$tmp = floatval($rs['temperature']);
			$smk = floatval($rs['smoke']);
			//$lpg = floatval($rs['lpg']);
			//$co = floatval($rs['co']);
			$hum = floatval($rs['humidity']);
			$timestamp = $rs['datetime'];
			//$wnddir = $rs['winddir'];
			$ffwi = $rs['ffwi'];
		}

// Create a PHP array and echo it as JSON
$ret = array($x,$timestamp, $smk, $hum, $tmp, $wndspd, $ffwi);
copy("C:/edss/serm.db","C:/edss/serm_shadow.db");
echo json_encode($ret);
?>
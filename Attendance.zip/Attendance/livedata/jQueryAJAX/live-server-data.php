<?php
copy("C:/edss/serm.db","C:/edss/serm_shadow.db");

// Set the JSON header
header("Content-type: text/json");

// The x value is the current JavaScript time, which is the Unix time multiplied 
// by 1000.

$x = time() * 1000;

		$conn = new mysqli("localhost", "root", "", "colibri");
				
		$result = $conn->query("SELECT * FROM data ORDER BY idnum DESC LIMIT 1");
		
		while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
			$wndspd = floatval($rs['windspeed']);
			$tmp = floatval($rs['temperature']);
			$smk = floatval($rs['smoke']);
			$hum = floatval($rs['humidity']);
			$timestamp = $rs['timestamp'];
			$wnddir = $rs['winddirection'];
		}

// Create a PHP array and echo it as JSON
$ret = array($x,$timestamp, $smk, $hum, $tmp, $wndspd, $wnddir);
echo json_encode($ret);
?>